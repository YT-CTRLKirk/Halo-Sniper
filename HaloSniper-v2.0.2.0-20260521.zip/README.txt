﻿Halo Sniper v2.0.2.0
========================================
Author:  CTRLKirk
Website: https://example.com/halosniper
Built:   2026-05-21

INSTALLATION
------------
1. Copy the 'HaloSniper' folder into your server's Mods/ directory.
2. Restart the server.

DESCRIPTION
-----------
The classic anti-material sniper rifle from Halo.
