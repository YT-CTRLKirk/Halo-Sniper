# Halo Sniper Rifle

This is my very first weapon mod for 7 Days to Die.

It adds a Halo-inspired sniper rifle to the game with custom sounds, a working zoom scope, and full attachment support. It uses standard 7.62mm ammo and fits right into the vanilla loot and crafting systems.

## How to Install

1. Copy the **HaloSniper** folder into your game's Mods directory: C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die\Mods

2. Launch the game.

## Features

- Custom 3D model and sounds
- Working zoom with scope overlay
- Supports weapon mods (scopes, barrels, flashlights, etc.)
- Uses vanilla 7.62mm Ball / HP / AP ammo

## Credits

Halo franchise assets belong to 343 Industries / Microsoft.
Built for the 7 Days to Die community.
SwallowWaterForMe for the Inspiration. 

Enjoy!